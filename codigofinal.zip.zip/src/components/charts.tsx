"use client"

import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from "recharts"

const data = [
  { name: "Seg", total: 4.5 },
  { name: "Ter", total: 3.2 },
  { name: "Qua", total: 6.0 },
  { name: "Qui", total: 2.8 },
  { name: "Sex", total: 5.5 },
  { name: "Sáb", total: 4.0 },
  { name: "Dom", total: 2.1 },
]

export function OverviewChart() {
  return (
    <ResponsiveContainer width="100%" height={350}>
      <BarChart data={data}>
        <XAxis
          dataKey="name"
          stroke="#888888"
          fontSize={12}
          tickLine={false}
          axisLine={false}
        />
        <YAxis
          stroke="#888888"
          fontSize={12}
          tickLine={false}
          axisLine={false}
          tickFormatter={(value) => `${value}h`}
        />
        <Tooltip 
          contentStyle={{ 
            backgroundColor: "#fff", 
            borderRadius: "8px", 
            border: "1px solid #e2e8f0" 
          }}
          labelStyle={{ fontWeight: "bold" }}
        />
        <Bar
          dataKey="total"
          fill="#0ea5e9"
          radius={[4, 4, 0, 0]}
        />
      </BarChart>
    </ResponsiveContainer>
  )
}

const pieData = [
  { name: "Matemática", value: 40, color: "#3b82f6" },
  { name: "Português", value: 25, color: "#ef4444" },
  { name: "Direito", value: 20, color: "#f59e0b" },
  { name: "História", value: 15, color: "#10b981" },
]

export function DistributionChart() {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <PieChart>
        <Pie
          data={pieData}
          cx="50%"
          cy="50%"
          innerRadius={60}
          outerRadius={80}
          paddingAngle={5}
          dataKey="value"
        >
          {pieData.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={entry.color} />
          ))}
        </Pie>
        <Tooltip />
      </PieChart>
    </ResponsiveContainer>
  )
}
