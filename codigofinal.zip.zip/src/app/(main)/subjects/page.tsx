"use client"

import { useState, useEffect } from "react"
import { Plus, Pencil, Trash2, Search } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { toast } from "sonner"

interface Subject {
  id: string
  name: string
  color: string
}

export default function SubjectsPage() {
  const [subjects, setSubjects] = useState<Subject[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState("")
  const [isAddOpen, setIsAddOpen] = useState(false)
  const [newName, setNewName] = useState("")
  const [newColor, setNewColor] = useState("#3b82f6")

  // Mock data for now until DB is connected
  useEffect(() => {
    const mockSubjects = [
      { id: "1", name: "Matemática", color: "#3b82f6" },
      { id: "2", name: "Português", color: "#ef4444" },
      { id: "3", name: "História", color: "#10b981" },
      { id: "4", name: "Direito Constitucional", color: "#f59e0b" },
      { id: "5", name: "Geografia", color: "#8b5cf6" },
    ]
    setSubjects(mockSubjects)
    setLoading(false)
  }, [])

  const filteredSubjects = subjects.filter(s => 
    s.name.toLowerCase().includes(search.toLowerCase())
  )

  const handleAddSubject = () => {
    if (!newName) return
    const newSubject = {
      id: Math.random().toString(),
      name: newName,
      color: newColor
    }
    setSubjects([...subjects, newSubject])
    setNewName("")
    setIsAddOpen(false)
    toast.success("Matéria adicionada com sucesso!")
  }

  const handleDelete = (id: string) => {
    if (confirm("Tem certeza que deseja excluir esta matéria?")) {
      setSubjects(subjects.filter(s => s.id !== id))
      toast.success("Matéria excluída.")
    }
  }

  return (
    <div className="p-8 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Matérias</h2>
          <p className="text-muted-foreground">Gerencie as disciplinas que você estuda.</p>
        </div>
        <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogTrigger asChild>
            <Button className="bg-sky-600 hover:bg-sky-700">
              <Plus className="h-4 w-4 mr-2" />
              Nova Matéria
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Adicionar Nova Matéria</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Nome</label>
                <Input 
                  placeholder="Ex: Direito Administrativo" 
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Cor</label>
                <div className="flex gap-2 flex-wrap">
                  {["#ef4444", "#3b82f6", "#10b981", "#f59e0b", "#8b5cf6", "#ec4899", "#6366f1", "#14b8a6"].map(c => (
                    <button
                      key={c}
                      className={`h-8 w-8 rounded-full border-2 transition ${newColor === c ? "border-black scale-110" : "border-transparent"}`}
                      style={{ backgroundColor: c }}
                      onClick={() => setNewColor(c)}
                    />
                  ))}
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddOpen(false)}>Cancelar</Button>
              <Button onClick={handleAddSubject}>Salvar</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex items-center bg-muted/50 rounded-lg px-3 py-2 max-w-md">
        <Search className="h-4 w-4 text-muted-foreground mr-2" />
        <Input 
          placeholder="Buscar matérias..." 
          className="border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredSubjects.map((subject) => (
          <Card key={subject.id} className="overflow-hidden group">
            <div 
              className="h-2 w-full" 
              style={{ backgroundColor: subject.color }} 
            />
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-lg font-bold">{subject.name}</CardTitle>
              <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition">
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <Pencil className="h-4 w-4" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-8 w-8 text-red-500 hover:text-red-600 hover:bg-red-50"
                  onClick={() => handleDelete(subject.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2 mt-2">
                <Badge variant="outline" className="text-xs font-normal">
                  12 sessões
                </Badge>
                <Badge variant="outline" className="text-xs font-normal">
                  45h total
                </Badge>
              </div>
            </CardContent>
          </Card>
        ))}
        {filteredSubjects.length === 0 && !loading && (
          <div className="col-span-full text-center py-10 text-muted-foreground">
            Nenhuma matéria encontrada.
          </div>
        )}
      </div>
    </div>
  )
}
