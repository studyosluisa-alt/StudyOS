"use client"

import { useState, useEffect } from "react"
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Plus, Filter, Download, Calendar as CalendarIcon } from "lucide-react"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { Badge } from "@/components/ui/badge"

interface Session {
  id: string
  subject: { name: string, color: string }
  startTime: Date
  duration: number
  manual: boolean
}

export default function HistoryPage() {
  const [sessions, setSessions] = useState<Session[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Mock data
    const mockSessions = [
      { 
        id: "1", 
        subject: { name: "Matemática", color: "#3b82f6" }, 
        startTime: new Date(), 
        duration: 5400, 
        manual: false 
      },
      { 
        id: "2", 
        subject: { name: "Português", color: "#ef4444" }, 
        startTime: new Date(Date.now() - 86400000), 
        duration: 3600, 
        manual: true 
      },
      { 
        id: "3", 
        subject: { name: "Direito Constitucional", color: "#f59e0b" }, 
        startTime: new Date(Date.now() - 86400000 * 2), 
        duration: 7200, 
        manual: false 
      },
    ]
    setSessions(mockSessions)
    setLoading(false)
  }, [])

  const formatDuration = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600)
    const mins = Math.floor((seconds % 3600) / 60)
    return `${hrs}h ${mins}m`
  }

  return (
    <div className="p-8 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Histórico de Estudos</h2>
          <p className="text-muted-foreground">Veja todos os seus registros passados.</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Exportar
          </Button>
          <Button className="bg-sky-600 hover:bg-sky-700">
            <Plus className="h-4 w-4 mr-2" />
            Lançamento Manual
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total de Sessões</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{sessions.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Média Diária</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3h 20m</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Dia Mais Produtivo</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">Segunda-feira</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Melhor Matéria</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">Matemática</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Logs Recentes</CardTitle>
          <Button variant="ghost" size="sm">
            <Filter className="h-4 w-4 mr-2" />
            Filtrar
          </Button>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Data</TableHead>
                <TableHead>Matéria</TableHead>
                <TableHead>Duração</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sessions.map((session) => (
                <TableRow key={session.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center">
                      <CalendarIcon className="h-4 w-4 mr-2 text-muted-foreground" />
                      {format(session.startTime, "dd 'de' MMM, yyyy", { locale: ptBR })}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      <div 
                        className="h-3 w-3 rounded-full mr-2" 
                        style={{ backgroundColor: session.subject.color }}
                      />
                      {session.subject.name}
                    </div>
                  </TableCell>
                  <TableCell>{formatDuration(session.duration)}</TableCell>
                  <TableCell>
                    {session.manual ? (
                      <Badge variant="secondary">Manual</Badge>
                    ) : (
                      <Badge variant="outline">Cronômetro</Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm">Ver</Button>
                  </TableCell>
                </TableRow>
              ))}
              {sessions.length === 0 && !loading && (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-10 text-muted-foreground">
                    Nenhum log de estudo encontrado.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
