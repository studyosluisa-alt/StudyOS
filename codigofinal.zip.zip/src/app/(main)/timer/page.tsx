"use client"

import { useState, useEffect, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Save,
  BookOpen
} from "lucide-react"
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { toast } from "sonner"

export default function TimerPage() {
  const [time, setTime] = useState(0)
  const [isRunning, setIsRunning] = useState(false)
  const [selectedSubject, setSelectedSubject] = useState<string>("")

  // Load from localStorage
  useEffect(() => {
    const savedTime = localStorage.getItem("study-timer-time")
    const savedIsRunning = localStorage.getItem("study-timer-isRunning")
    const lastUpdate = localStorage.getItem("study-timer-lastUpdate")

    if (savedTime) {
      let currentTime = parseInt(savedTime)
      if (savedIsRunning === "true" && lastUpdate) {
        const diff = Math.floor((Date.now() - parseInt(lastUpdate)) / 1000)
        currentTime += diff
        setIsRunning(true)
      }
      setTime(currentTime)
    }
  }, [])

  // Save to localStorage
  useEffect(() => {
    localStorage.setItem("study-timer-time", time.toString())
    localStorage.setItem("study-timer-isRunning", isRunning.toString())
    localStorage.setItem("study-timer-lastUpdate", Date.now().toString())
  }, [time, isRunning])

  useEffect(() => {
    let interval: NodeJS.Timeout
    if (isRunning) {
      interval = setInterval(() => {
        setTime((prev) => prev + 1)
      }, 1000)
    }
    return () => clearInterval(interval)
  }, [isRunning])

  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600)
    const mins = Math.floor((seconds % 3600) / 60)
    const secs = seconds % 60
    return `${hrs.toString().padStart(2, "0")}:${mins
      .toString()
      .padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const handleStartPause = () => {
    if (!selectedSubject && !isRunning) {
      toast.error("Por favor, selecione uma matéria primeiro.")
      return
    }
    setIsRunning(!isRunning)
  }

  const handleReset = () => {
    if (confirm("Tem certeza que deseja resetar o cronômetro?")) {
      setTime(0)
      setIsRunning(false)
      localStorage.removeItem("study-timer-time")
      localStorage.removeItem("study-timer-isRunning")
      localStorage.removeItem("study-timer-lastUpdate")
    }
  }

  const handleSave = async () => {
    if (time < 60) {
      toast.error("O tempo de estudo deve ser de pelo menos 1 minuto.")
      return
    }
    
    // Here we would call the API to save
    toast.success("Sessão salva com sucesso!")
    setTime(0)
    setIsRunning(false)
  }

  return (
    <div className="p-8 max-w-4xl mx-auto space-y-8">
      <div className="flex flex-col items-center justify-center space-y-4">
        <h2 className="text-3xl font-bold tracking-tight">Cronômetro de Estudo</h2>
        <p className="text-muted-foreground">Foque no seu progresso, nós cuidamos do tempo.</p>
      </div>

      <Card className="w-full">
        <CardHeader className="text-center">
          <CardTitle className="text-sm font-medium uppercase tracking-wider text-muted-foreground">
            Tempo Decorrido
          </CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col items-center space-y-8 pb-10">
          <div className="text-8xl font-mono font-bold tracking-tighter tabular-nums">
            {formatTime(time)}
          </div>

          <div className="w-full max-w-xs space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Matéria</label>
              <Select onValueChange={setSelectedSubject} value={selectedSubject}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione uma matéria" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="matematica">Matemática</SelectItem>
                  <SelectItem value="portugues">Português</SelectItem>
                  <SelectItem value="historia">História</SelectItem>
                  <SelectItem value="direito-const">Direito Constitucional</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <Button 
              size="lg" 
              variant="outline" 
              className="h-16 w-16 rounded-full"
              onClick={handleReset}
            >
              <RotateCcw className="h-6 w-6" />
            </Button>
            
            <Button 
              size="lg" 
              className={cn(
                "h-24 w-24 rounded-full shadow-lg transition-all active:scale-95",
                isRunning ? "bg-red-500 hover:bg-red-600" : "bg-green-500 hover:bg-green-600"
              )}
              onClick={handleStartPause}
            >
              {isRunning ? (
                <Pause className="h-10 w-10 text-white" />
              ) : (
                <Play className="h-10 w-10 text-white ml-1" />
              )}
            </Button>

            <Button 
              size="lg" 
              variant="outline" 
              className="h-16 w-16 rounded-full"
              onClick={handleSave}
              disabled={time === 0 || isRunning}
            >
              <Save className="h-6 w-6" />
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6 flex flex-col items-center">
            <BookOpen className="h-8 w-8 mb-2 text-sky-500" />
            <p className="text-sm font-medium">Meta Diária</p>
            <p className="text-2xl font-bold">4h 00m</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6 flex flex-col items-center">
            <TrendingUp className="h-8 w-8 mb-2 text-green-500" />
            <p className="text-sm font-medium">Progresso Hoje</p>
            <p className="text-2xl font-bold">75%</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6 flex flex-col items-center">
            <Clock className="h-8 w-8 mb-2 text-orange-500" />
            <p className="text-sm font-medium">Faltam</p>
            <p className="text-2xl font-bold">1h 00m</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(" ")
}
